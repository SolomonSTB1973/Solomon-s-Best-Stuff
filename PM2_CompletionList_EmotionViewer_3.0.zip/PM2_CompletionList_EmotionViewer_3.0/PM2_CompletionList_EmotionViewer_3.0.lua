-- script for discovering what makes the completion percentage in
-- Pac-Man 2: The New Adventures (GEN/SNES) tick.
-- Modified by SolomonSTB1973 to make emotion handler work with SNES ROM.
-- Version 3.0!
-- Fully supports GEN, Super Famicom and European SNES versions.
-- Adds new type of area-specific tracker (old tracker still in game)
-- Adds "untracked" mode, which shows a percentage for untracked events (toggled on/off)
-- Not 100% tested, but should work.  Also, event names still need revising
--
-- originally written by Slabbityslab and Insomnimatics, with help finding events by kickasspancakes, AludraKijurorin, Mr Wayne and BaconOmelette, shoutouts to Danilo Roxette
-- 
-- 
--
-- SPDX-License-Identifier: CC0-1.0
--

-------------------------------------------------------------------------------
-- script for viewing, changing and locking Pac-Man's emotion value written by Insomnimatics
--
-- Controller inputs used in script:
-- L/X: Lowers the emotion value by 1
-- R/Y: Raises the emotion value by 1
-- A/Z: Locks emotion value from changing

--== Shortcuts ==--
local rb     = memory.read_u8
local rbs    = memory.read_s8
local rw     = memory.read_u16_be
local mmrl-- = mainmemory.read_u16_le
local rws    = memory.read_s16_be
local rl  -- = memory.read_u32_be
local rll -- = memory.read_u32_le
local ww     = memory.write_u16_be
local wwl    = memory.write_u16_le
local mmw -- = mainmemory.write_u16_be
local mmwl-- = mainmemory.write_u16_le
local box    = gui.drawBox
local text   = gui.pixelText
local line   = gui.drawLine
local AND    = bit.band
local SHIFTL = bit.lshift
local SHIFTR = bit.rshift

-- AARRGGBB
local ColorProgress  = 0xFFFFFF00
local ColorTracked   = 0xFF00FFFF
local ColorUntracked = 0xFFFFA500

local ObjectMasksAddr = 0
local ObjectMasksDomain = nil
local ObjectStatesAddr = 0
local ObjectStatesDomain = nil

--Location Vars --This is now defined under each version
local location					
--C7F8 and C81E likely candidates

--Emotion Viewer Vars
local p_emotion  --This is now defined under each version				 
local lockedEmotion = false
local textColor
local Pressed1 = false
local Pressed2 = false
local Pressed3 = false
local currentEmotion
local lockedEmotionValue = 15
local button1
local button2
local button3
local button4
local button5

--UntrackedMode Vars
local visible = false
local pressed = false 
local line1 = 0
local line2 = 1000
local line3 = 1000
local line4 = 7
local line5 = 28


--Area Vars
local tutvar = 44
local pmhvar = 4
local vwvar = 5
local pkvar = 6
local oavar = 7
local sfvar = 8
local rwsvar = 9
local frvar = 10
local etcvar = 11
local mc1var = 12
local apvar = 13
local cavar = 14
local cliffvar = 15
local hgl1var = 16
local hillvar = 17
local mtnvar = 18
local ssvar = 19
local ftnvar = 20
local mstvar = 21
local IAvar = 22
local swrvar = 23
local whsvar = 24
local spntvar = 25
local biovar = 26
local ldrvar = 27
local rftpvar = 28
local pullyvar = 29
local undbvar = 30
local ipmhvar = 32
local lhvar = 33
local ogcvar = 34
local gcntrvar = 36
local dpmtsvar = 37
local gmnstr = 38
local sctpthvar = 39
local mcrt2var = 40
local supassvar = 41
local sctrnwyvar = 42
local hgdr2var = 43

		
if (memory.read_u32_be(0x100) == 0x53454741) then
    -- Genesis version (has "SEGA" in right spot)
    ObjectMasksAddr = 0x0451A4
    ObjectMasksDomain = "MD CART"
    ObjectStatesAddr = 0xFB00
    ObjectStatesDomain = "68K RAM"
		location = 0xC7F8   ----0x000502 
		p_emotion = 0xE840
		rll    = memory.read_u32_be 
		mmwl    = mainmemory.write_u16_be
		mmrl    = mainmemory.read_u16_be
		button1 = 'P1 X'
		button2 = 'P1 Y'
		button3 = 'P1 Z'
		button4 = 'P1 B'
		button5 = 'P1 A'
		tutvar = 40
		pmhvar = 44
		vwvar = 1
		pkvar = 9
		oavar = 19
		sfvar = 24
		rwsvar = 2
		frvar = 3
		etcvar = 4
		mc1var = 6
		apvar = 15
		cavar = 7
		cliffvar = 20
		hgl1var = 8
		hillvar = 21
		mtnvar = 17
		ssvar = 30
		ftnvar = 31
		mstvar = 32
		IAvar = 26
		swrvar = 25
		whsvar = 37
		spntvar = 38
		biovar = 39
		ldrvar = 28
		rftpvar = 34
		pullyvar = 35
		undbvar = 36
		ipmhvar = 11
		lhvar = 10
		ogcvar = 13
		gcntrvar = 14
		dpmtsvar = 33
		gmnstr = 29
		sctpthvar = 22
		mcrt2var = 23
		supassvar = 16
		sctrnwyvar = 5
		hgdr2var = 18

   		print("This is the GEN version!")
		print("Press A+B to view Area Events Tracker.")
		print("Press X/Y to change emotions.")
		print("Press Z to lock emotions.")
		print("Press A+B+X to view Total Events Tracker.")
		print("Press A+B+X+Y to toggle Untracked mode.")
		print("\n")
else 
if (memory.read_u32_le(0x100, "CARTROM") == 0x4D414E20) then
    --This is the SNES version
   	ObjectMasksAddr = 0xBA69
    	ObjectMasksDomain = "CARTROM"
    	ObjectStatesAddr = 0xD80
   	ObjectStatesDomain = "WRAM"
		location = 0x000502
		p_emotion = 0x0002C0
		rll    = memory.read_u32_le 
		mmwl   = mainmemory.write_u16_le
		mmrl   = mainmemory.read_u16_le
		button1 = 'P1 L'
		button2 = 'P1 R'
		button3 = 'P1 A'
		button4 = 'P1 B'
		button5 = 'P1 X'
  		print("This is the US SNES version!")
		print("Press B+X to view Area Events Tracker.")
		print("Press L/R to change emotions.")
		print("Press A to lock emotions.")
		print("Press B+X+L to view Total Events Tracker.")
		print("Press B+X+L+R to toggle Untracked mode.")
		print("\n")
elseif (memory.read_u32_le(0x100, "CARTROM") == 0x41525541) then
    -- This is the Europe Version
 	   ObjectMasksAddr = 0xBACC
   	 ObjectMasksDomain = "CARTROM"
   	 ObjectStatesAddr = 0xD80
   	 ObjectStatesDomain = "WRAM"
		location = 0x000502
		p_emotion = 0x0002C0
		rll    = memory.read_u32_le 
		mmwl   = mainmemory.write_u16_le
		mmrl   = mainmemory.read_u16_le
		button1 = 'P1 L'
		button2 = 'P1 R'
		button3 = 'P1 A'
		button4 = 'P1 B'
		button5 = 'P1 X'
   		print("This is the EU SNES version!")
		print("Press B+X to view Area Events Tracker.")
		print("Press L/R to change emotions.")
		print("Press A to lock emotions.")
		print("Press B+X+L to view Total Events Tracker.")
		print("Press B+X+L+R to toggle Untracked mode.")
		print("\n")
elseif (memory.read_u32_le(0x100, "CARTROM") == 0x434D414E) then
    -- This is the Super Famicom Version 
   	 ObjectMasksAddr = 0xBAB3
   	 ObjectMasksDomain = "CARTROM"
   	 ObjectStatesAddr = 0xD80
    	ObjectStatesDomain = "WRAM"
		location = 0x000502
		p_emotion = 0x0002C0
		rll    = memory.read_u32_le 
		mmwl   = mainmemory.write_u16_le
		mmrl   = mainmemory.read_u16_le
		button1 = 'P1 L'
		button2 = 'P1 R'
		button3 = 'P1 A'
		button4 = 'P1 B'
		button5 = 'P1 X'
   		 print("This is the Super Famicom version!")
		print("Press B+X to view Area Events Tracker.")
		print("Press L/R to change emotions.")
		print("Press A to lock emotions.")
		print("Press B+X+L to view Total Events Tracker.")
		print("Press B+X+L+R to toggle Untracked mode.")
		print("\n")
else
--Unrecognised rom!
   	 ObjectMasksAddr = 0xBA69
    	ObjectMasksDomain = "CARTROM"
    	ObjectStatesAddr = 0xD80
    	ObjectStatesDomain = "WRAM"
		location = 0x000502
		p_emotion = 0x0002C0
		rll    = memory.read_u32_le 
		mmwl   = mainmemory.write_u16_le
		mmrl   = mainmemory.read_u16_le
		button1 = 'P1 L'
		button2 = 'P1 R'
		button3 = 'P1 A'
		button4 = 'P1 B'
		button5 = 'P1 X'
  		print("Rom Unrecognised! Defaulting to USA Snes!")
		print("Press B+X to view Area Events Tracker.")
		print("Press L/R to change emotions.")
		print("Press A to lock emotions.")
		print("Press B+X+L to view Total Events Tracker.")
		print("Press B+X+L+R to toggle Untracked mode.")
		print("\n")
end
end


-- local array to keep track of newly-completed objects
-- Legacy, can't delete
local CompletionTrack = {}
local function InitCompletionTrack()
    for i = 0, 0xf do
        local state_value = memory.read_u32_le(ObjectStatesAddr + (i*4), ObjectStatesDomain)
        for b = 0, 31 do
            local id = SHIFTL(i, 5) + b
            if (AND(state_value, SHIFTL(1, b)) ~= 0) then
                CompletionTrack[id] = true
            else
                CompletionTrack[id] = false
            end
        end
    end
end
InitCompletionTrack()

-- local array to keep track of whether events are required or not.
-- Was true false, trying 1, 0
local RequiredTrack = {}
local function InitRequiredTrack()
    for i = 0, 0xf do
        local mask_value = memory.read_u32_le(ObjectMasksAddr + (i*4), ObjectMasksDomain)
        for b = 0, 31 do
            local id = SHIFTL(i, 5) + b
            if (AND(mask_value, SHIFTL(1, b)) ~= 0) then
                RequiredTrack[id] = true
            else
                RequiredTrack[id] = false
            end
        end
    end
end
InitRequiredTrack()

local EventNames = {}
EventNames[0] = "UNIVERSAL? Enter any area?"
EventNames[1] = "1-26 part of tutorial."
EventNames[2] = "1-26 part of tutorial."
EventNames[3] = "1-26 part of tutorial."
EventNames[4] = "1-26 part of tutorial."
EventNames[5] = "1-26 part of tutorial."
EventNames[6] = "1-26 part of tutorial."
EventNames[7] = "1-26 part of tutorial."
EventNames[8] = "1-26 part of tutorial."
EventNames[9] = "1-26 part of tutorial."
EventNames[10] = "1-26 part of tutorial."
EventNames[11] = "1-26 part of tutorial."
EventNames[12] = "1-26 part of tutorial."
EventNames[13] = "1-26 part of tutorial."
EventNames[14] = "1-26 part of tutorial."
EventNames[15] = "1-26 part of tutorial."
EventNames[16] = "1-26 part of tutorial."
EventNames[17] = "1-26 part of tutorial."
EventNames[18] = "1-26 part of tutorial."
EventNames[19] = "1-26 part of tutorial."
EventNames[20] = "1-26 part of tutorial."
EventNames[21] = "1-26 part of tutorial."
EventNames[22] = "1-26 part of tutorial."
EventNames[23] = "1-26 part of tutorial."
EventNames[24] = "1-26 part of tutorial."
EventNames[25] = "1-26 part of tutorial."
EventNames[26] = "1-26 part of tutorial."
EventNames[27] = "<untracked> <???>"
EventNames[28] = "<untracked> <???>"
EventNames[29] = "<untracked> <???>"
EventNames[30] = "<untracked> <???>"
EventNames[31] = "<untracked> <???>"
EventNames[32] = "<untracked> <???>"
EventNames[33] = "<untracked> <???>"
EventNames[34] = "Tutorial, don't shoot what Pac-man is asking for."
EventNames[35] = "Tutorial, Pac-man walks back to center stage."
EventNames[36] = "Universal? Or during tutorial? Get knocked unconscious."
EventNames[37] = "<untracked> <???>"
EventNames[38] = "<untracked> <???>"
EventNames[39] = "<untracked> <???>"
EventNames[40] = "<untracked> <???>"
EventNames[41] = "<untracked> UNIVERSAL? Look up."
EventNames[42] = "<untracked> UNIVERSAL? Look left-right?"
EventNames[43] = "<untracked> UNIVERSAL? Look down."
EventNames[44] = "<untracked> UNIVERSAL? Look right-left?"
EventNames[45] = "<untracked> <???>"
EventNames[46] = "<untracked> <???>"
EventNames[47] = "<untracked> UNIVERSAL? Encounter ghosts"
EventNames[48] = "<untracked> UNIVERSAL? Feed Pac-Man a Power Pellet"
EventNames[49] = "<untracked> UNIVERSAL? Shoot Pac-Man."
EventNames[50] = "<untracked> Shoot pac-man after falling from tree branch"
EventNames[51] = "<untracked> something with sewers?"
EventNames[52] = "<untracked> Shoot to make him jump"
EventNames[53] = "<untracked> Hit pac man to jump onto rope"
EventNames[54] = "<untracked> industrial area <???>"
EventNames[55] = "<untracked> Hit pac man when he's looking over edge"
EventNames[56] = "<untracked> Hit pac man"
EventNames[57] = "<untracked> UNIVERSAL? Shoot Pacman out of 'mood'"
EventNames[58] = "<untracked> Hit pac man over sewer manhole or rake."
EventNames[59] = "<untracked> Hit pac man to make him jump onto platform"
EventNames[60] = "<untracked> Help pac man jump between rooftops or jump off skateboard"
EventNames[61] = "<untracked> <???>"
EventNames[62] = "Tutorial? Shoot Pac-Man"
EventNames[63] = "<untracked> <???>"
EventNames[64] = "Tutorial? Do nothing."
EventNames[65] = "Tutorial: Do nothing when asked to point out airplane."
EventNames[66] = "Tutorial: Make pacman keep asking for pellets."
EventNames[67] = "Old Arcade: *MISSABLE* Get denied at train station"
EventNames[68] = "Anywhere?: hit a door"
EventNames[69] = "Stock Farm: *MISSABLE* Investigate ropeway station before chapter 2"
EventNames[70] = "Main St: Fix the hydrant"
EventNames[71] = "Main St: Block the hydrant"
EventNames[72] = "Main St: Blow off sewer cover"
EventNames[73] = "Main St: Blow off sewer cover (still)"
EventNames[74] = "Pac-Man's House: Spin windmill"
EventNames[75] = "Pac-Man's House: Chased by windmill"
EventNames[76] = "Pac-Man's House: Eyeball Window"
EventNames[77] = "Pac-Man's House: Mailbox"
EventNames[78] = "Pac-Man's House: Play the drums"
EventNames[79] = "<untracked> Pac-Man's House: Exit the house"
EventNames[80] = "Many Places: Look around."
EventNames[81] = "<untracked> <???>"
EventNames[82] = "<untracked> Old Game Center: Enter"
EventNames[83] = "<untracked> <???>"
EventNames[84] = "<untracked> <???>"
EventNames[85] = "<untracked> <???>"
EventNames[86] = "Many Places: Trigger Ghosts / get spooked by ghosts"
EventNames[87] = "Many Places: Terrified by Ghosts"
EventNames[88] = "Fountain Way: Sit on bench"
EventNames[89] = "Fountain Way: Eat apple / have smug pacman jump on the bench and get smashed"
EventNames[90] = "Fountain Way: Spin revolving door"
EventNames[91] = "Fountain Way: Same as 92"
EventNames[92] = "Fountain Way: Get caught in revolving door"
EventNames[93] = "<untracked> Fountain Way: Exit department store"
EventNames[94] = "Old Game Center: Investigate the Pac-Man machine"
EventNames[95] = "Old Game Center: Investigate the MrsPacJr machine"
EventNames[96] = "Main St: Chased by bees, fall down manhole?"
EventNames[97] = "Station St: See the burger sign"
EventNames[98] = "Station St: Shimmy around painter from left"
EventNames[99] = "Station St: Slingshot the painter?"
EventNames[100] = "Station St: Drop the paint can"
EventNames[101] = "Station St: Drop the paint can on Pac mid-shimmy"
EventNames[102] = "Station St: Get paint can dropped on head"
EventNames[103] = "Station St: Shimmy around painter from right"
EventNames[104] = "Fountain Way: Look in shop window"
EventNames[105] = "Fountain Way: Kick/poke/push cart from left."
EventNames[106] = "Fountain Way: Shoot cart to get Pacman's attention."
EventNames[107] = "Fountain Way: Enter shopping cart by being distracted by department display"
EventNames[108] = "Fountain Way: Cart collides with wall."
EventNames[109] = "<untracked> <???>"
EventNames[110] = "Fountain Way: Exit to Main St"
EventNames[111] = "Fountain Way: Take a balloon"
EventNames[112] = "Fountain Way: Anger the balloon vendor"
EventNames[113] = "Fountain Way: Pop a held balloon"
EventNames[114] = "Fountain Way: Let go of the balloon"
EventNames[115] = "Fountain Way: look at a fish"
EventNames[116] = "Fountain Way: Shoot the fish"
EventNames[117] = "Fountain Way: bring out a fish? Jump into water?"
EventNames[118] = "Fountain Way: Shoot the water a second time?" 
EventNames[119] = "Fountain Way: Eat a Cherry"
EventNames[120] = "Fountain Way: Sad/Scared Pacman crawls under bench, lure him out with apple"
EventNames[121] = "Station St: Stop before puddle"
EventNames[122] = "Station St: Get splashed by car"
EventNames[123] = "Station St: *SNES ONLY* Have Pacman jump back on his own when puddle gets splashed"
EventNames[124] = "Station St: *MISSABLE* CH3: Be distracted by the burger UFO"
EventNames[125] = "Station St: *MISSABLE* CH3: Kick the statue out of anger"
EventNames[126] = "Station St: *MISSABLE* CH3: Shoot the statue's head"
EventNames[127] = "Station St: CH4: Ride the bucket to Pulley Area"
EventNames[128] = "<untracked> <???>"
EventNames[129] = "<untracked> <???>"
EventNames[130] = "Industrial Area: Dust bin?"
EventNames[131] = "Industrial Area: Attempt to get a cola"
EventNames[132] = "Industrial Area: Rage at cola machine"
EventNames[133] = "Industrial Area: Trigger cola slots"
EventNames[134] = "Industrial Area: Cola slot jackpot"
EventNames[135] = "Rooftop: Look out over edge"
EventNames[136] = "Rooftop: Can't reach the hook"
EventNames[137] = "Rooftop: Ride the hook"
EventNames[138] = "Main St: Make Lucy's friend cry"
EventNames[139] = "Department Store: Enter"
EventNames[140] = "Under Building: Step on the loose girder"
EventNames[141] = "Department Store: Launch the triangle"
EventNames[142] = "Department Store: Catch the triangle"
EventNames[143] = "Department Store: Run away in fear"
EventNames[144] = "<untracked> Rooftop: Fall into vent"
EventNames[145] = "Rooftop: Look into vent"
EventNames[146] = "Department Store: Hit cashier while Pac-man is in a good mood (8)."
EventNames[147] = "<untracked> Department Store: Hit cashier"
EventNames[148] = "Department Store: Shoot lady at counter while not in good mood?"
EventNames[149] = "Rooftop: Shoot Pac-Man off the hook ride"
EventNames[150] = "Department Store: Play the drums"
EventNames[151] = "Main St: Stick hand in left mousehole"
EventNames[152] = "Main St: Stick hand in right mousehole"
EventNames[153] = "Main St: See the mousehole"
EventNames[154] = "Main St: Chased by bees, fall down manhole?"
EventNames[155] = "Industrial Area: Guard is sus"
EventNames[156] = "Industrial Area: Slingshot the gate"
EventNames[157] = "Industrial Area: Blocked by guard"
EventNames[158] = "Industrial Area: Picked up and tossed by guard"
EventNames[159] = "Entrance to Cave: Leap into the chasm"
EventNames[160] = "Pulley Area: Enter"
EventNames[161] = "<untracked> <???> station street"
EventNames[162] = "<untracked> <???> Department store area? Kick cart emotion 3"
EventNames[163] = "Industrial Area: Drop in via Under Building"
EventNames[164] = "Old Arcade: See the cat"
EventNames[165] = "Old Arcade: Hit the cat"
EventNames[166] = "Old Arcade: Cat steals hot dog"
EventNames[167] = "Old Arcade: *SNES ONLY* Shoot trash can after cat has stolen Hot Dog."
EventNames[168] = "Old Arcade: Hit trash can hiding hot dog thief"
EventNames[169] = "Old Arcade: Get into a cat fight"
EventNames[170] = "Old Arcade: Consider getting a hot dog"
EventNames[171] = "Old Arcade: Take a hot dog"
EventNames[172] = "Old Arcade: Get ketchuped by angry hot dog vendor"
EventNames[173] = "Old Arcade: Bump into hot dog cart"
EventNames[174] = "Old Arcade: Look in trash can cat jumped out of"
EventNames[175] = "Old Arcade: Catch cat that has stolen hot dog"
EventNames[176] = "Old Arcade: Hit hot dog stand while chasing cat (Emotion 5/8 helps)"
EventNames[177] = "Department Store: See the piano"
EventNames[178] = "Old Game Center: Stop playing the Pac Jr machine"
EventNames[179] = "Old Arcade/Station Street: *SNES ONLY* Same as 180."
EventNames[180] = "Old Arcade/Station Street: *SNES ONLY* Hit Arcade door."
EventNames[181] = "Main St: Shoot flower pots off and scare Pac-Man" 
EventNames[182] = "<untracked> <???>"
EventNames[183] = "Under Building: Look at smoke rings"
EventNames[184] = "Lucy's Room: Enter"
EventNames[185] = "Many Places: Head twoards the exit."
EventNames[186] = "Lucy's Room: Slingshot Lucy"
EventNames[187] = "Lucy's Room: Get the cartridge"
EventNames[188] = "Lucy's Room: Get pie"
EventNames[189] = "Park: Spin clock and look, Pacman gets angry"
EventNames[190] = "Park: Dance at noon"
EventNames[191] = "Pac-Man's House: Play with dog"
EventNames[192] = "Pac-Man's House: Shoot dog"
EventNames[193] = "<untracked> <???>"
EventNames[194] = "<untracked> <???>"
EventNames[195] = "Pac-Man's Room: Enter"
EventNames[196] = "Pac-Man's Room: Wake up with clock"
EventNames[197] = "Pac-Man's Room: Drop portrait"
EventNames[198] = "Old Arcade: Hit the CLOSED sign"
EventNames[199] = "Park: Trip over rock"
EventNames[200] = "Park: Avoid the left rock"
EventNames[201] = "Park: Avoid the right rock"
EventNames[202] = "Park: Skateboard into rock"
EventNames[203] = "Park: Angry kick skateboard into rock"
EventNames[204] = "Park: Land on the skateboard"
EventNames[205] = "Park: Look up at skateboard"
EventNames[206] = "Park: Get hit in head by skateboard"
EventNames[207] = "Rooftop: Get hit by birds"
EventNames[208] = "Rooftop: Shoot the birds"
EventNames[209] = "Old Arcade: *SNES ONLY* See hot dog on ground."
EventNames[210] = "Station St: Cross puddle without being splashed"
EventNames[211] = "Fountain Way: See hot dog"
EventNames[212] = "Fountain Way: Shoot the water once?"
EventNames[213] = "<untracked> Park: respawn after bee attack?"
EventNames[214] = "<untracked> Main St: Climb down into sewers"
EventNames[215] = "<untracked> <???>"
EventNames[216] = "<untracked> <???>"
EventNames[217] = "Park/Village Way: *MISSABLE* Leftward Milk sign before getting milk"
EventNames[218] = "Park/Old Arcade: *MISSABLE* Right-facing Milk Sign before getting milk"
EventNames[219] = "Park/Arcade/Village: Shoot Milk sign AFTER getting milk once."
EventNames[220] = "Department store: Shoot guitar up top during chapter 3"
EventNames[221] = "<untracked> Department Shoot guitar up top during chapter 4"
EventNames[222] = "<untracked> <???> Unusued?"
EventNames[223] = "<untracked> <???> Unusued?"
EventNames[224] = "<untracked> <???> Unusued?"
EventNames[225] = "<untracked> <???> Unusued?"
EventNames[226] = "<untracked> <???> Unusued?"
EventNames[227] = "<untracked> <???> Unusued?"
EventNames[228] = "<untracked> <???> Unusued?"
EventNames[229] = "<untracked> <???> Unusued?"
EventNames[230] = "<untracked> <???> Unusued?"
EventNames[231] = "<untracked> <???> Unusued?"
EventNames[232] = "<untracked> <???> Unusued?"
EventNames[233] = "<untracked> <???> Unusued?"
EventNames[234] = "<untracked> <???> Unusued?"
EventNames[235] = "<untracked> <???> Unusued?"
EventNames[236] = "<untracked> <???> Unusued?"
EventNames[237] = "<untracked> <???> Unusued?"
EventNames[238] = "<untracked> <???> Unusued?"
EventNames[239] = "<untracked> <???> Unusued?"
EventNames[240] = "<untracked> <???> Unusued?"
EventNames[241] = "<untracked> <???> Unusued?"
EventNames[242] = "<untracked> <???> Unusued?"
EventNames[243] = "<untracked> <???> Unusued?"
EventNames[244] = "<untracked> <???> Unusued?"
EventNames[245] = "<untracked> <???> Unusued?"
EventNames[246] = "<untracked> <???> Unusued?"
EventNames[247] = "<untracked> <???> Unusued?"
EventNames[248] = "<untracked> <???> Unusued?"
EventNames[249] = "<untracked> <???> Unusued?"
EventNames[250] = "<untracked> <???> Unusued?"
EventNames[251] = "<untracked> <???> Unusued?"
EventNames[252] = "<untracked> <???> Unusued?"
EventNames[253] = "<untracked> <???> Unusued?"
EventNames[254] = "<untracked> <???> Unusued?"
EventNames[255] = "<untracked> <???> Unusued?"
EventNames[256] = "Ropeway Station: Slingshot the rope"
EventNames[257] = "Ropeway Station: Climb the rope to Cliff"
EventNames[258] = "Ropeway Station: Shoot Pac-Man off the rope"
EventNames[259] = "Cliff: Climb the rope to Ropeway Station"
EventNames[260] = "Entrance of Cave: Enter minecart"
EventNames[261] = "Entrance of Cave: Shoot the minecart away with Pac watching"
EventNames[262] = "<untracked> Entrance of Cave: try to enter with minecart gone"
EventNames[263] = "Arrival Point: Exit minecart"
EventNames[264] = "<untracked> Arrival Point: See the cliff"
EventNames[265] = "Cliff: Drop the glider"
EventNames[266] = "<untracked> cliff"
EventNames[267] = "Park: Enter via Hidden Runway glider"
EventNames[268] = "<untracked> Hillock: Shake glider"
EventNames[269] = "<untracked> <???>"
EventNames[270] = "Cliff: Fear the edge"
EventNames[271] = "Ropeway Station: Investigate waterfall"
EventNames[272] = "Ropeway Station: Try to push hidden door from left side"
EventNames[273] = "Ropeway Station: Walk through the open hidden door"
EventNames[274] = "Ropeway Station: Try to push hidden door from right side"
EventNames[275] = "Construct Area: Get water dropped on head while in emotion 5?"
EventNames[276] = "Construct Area: Patch the sandbag"
EventNames[277] = "Construct Area: Free the mouse"
EventNames[278] = "Construct Area: Rage against the machine"
EventNames[279] = "Construct Area: Get the pulley machine working"
EventNames[280] = "Construct Area: Look at the box without shooting it"
EventNames[281] = "Construct Area: Close the box"
EventNames[282] = "Construct Area: Open any crate"
EventNames[283] = "Construct Area: Open pizza crate"
EventNames[284] = "Forest: Bump tree and drop caterpillars"
EventNames[285] = "Forest: Be scared of caterpillars"
EventNames[286] = "Forest: Eat the orange berry"
EventNames[287] = "Forest: Eat the purple berry"
EventNames[288] = "<untracked> Top of Mtn: drop a vine?"
EventNames[289] = "Top of Mtn: Pull first vine, get pulled"
EventNames[290] = "Top of Mtn: Pull second vine, get apple core"
EventNames[291] = "Top of Mtn: Pull third vine, get rabbit"
EventNames[292] = "<untracked> Top of Mtn: Pull fourth vine, fall in hole"
EventNames[293] = "Top of Mtn: Pull fourth vine, open hole"
EventNames[294] = "<untracked> <???>"
EventNames[295] = "<untracked> Top of Mtn: drop all vines?"
EventNames[296] = "Top of Mtn: Follow the rabbit?"
EventNames[297] = "Top of Mtn: Explore flower patch"
EventNames[298] = "<untracked> Top of Mtn: flower patch?"
EventNames[299] = "Fountain Way: Eat orange berry in fountain way."
EventNames[300] = "Forest: Shoot away a log about to hit Pac"
EventNames[301] = "<untracked> Secret Plant: Break the alarm sensor"
EventNames[302] = "Hillock: Get flock of birds out of tree"
EventNames[303] = "Construct Area: Water drop on head"
EventNames[304] = "Forest: Slingshot the rock"
EventNames[305] = "Forest: Trip over rock into logs"
EventNames[306] = "<untracked> Forest: Look at rock?"
EventNames[307] = "<untracked> Forest: Trip over rock right-to-left"
EventNames[308] = "Forest: Angrily kick the rock into logs"
EventNames[309] = "Forest: Kick over rock"
EventNames[310] = "Forest: Chase a butterfly"
EventNames[311] = "Forest: Look at butterfly after it's moved."
EventNames[312] = "<untracked> Ropeway Station: Go drunk-mode at Dan Ger's sign"
EventNames[313] = "Ropeway Station: React to DAN GER sign from right side."
--*MISSABLE* See rope at ceiling BEFORE shooting it down *OR* approach sign from right while emotion 10?"
EventNames[314] = "<untracked> Ropeway Station: Flip Dan Ger's sign"
EventNames[315] = "<untracked> Secret Plant: Get carried off by ghost"
EventNames[316] = "<untracked> <???> secret plant"
EventNames[317] = "<untracked> Construct Area: Get pellet from behind minecart"
EventNames[318] = "<untracked> Cliff: Get turned around?"
EventNames[319] = "<untracked> <???>"
EventNames[320] = "Sewers: Look at mouse hole"
EventNames[321] = "Sewers: Get kicked by mouse"
EventNames[322] = "Sewers: Shoot Pacman before rat bites him"
EventNames[323] = "Sewers: Look inside mouse hole"
EventNames[324] = "Sewers: Investigate large hole"
EventNames[325] = "Sewers: Chase out thieves"
EventNames[326] = "Sewers: Beat up by thieves"
EventNames[327] = "Sewers: Catch the thieves"
EventNames[328] = "Sewers: Enter large hole"
EventNames[329] = "Warehouse: Investigate Blinky's Pan"
EventNames[330] = "Secret Plant: Look up at hook"
EventNames[331] = "Sewers: Look at middle ladder"
EventNames[332] = "Sewers/Main St: Have object dropped on head"
EventNames[333] = "Sewers: Look at right ladder"
EventNames[334] = "Sewers: Climb right ladder"
EventNames[335] = "Sewers: Get shot off right ladder"
EventNames[336] = "Secret Plant: Enter"
EventNames[337] = "Secret Plant: Land in ghost box"
EventNames[338] = "Secret Plant: Something on the conveyor belt?? Look away from ghost machine??"
EventNames[339] = "Secret Plant: Shoot the hook to grab it"
EventNames[340] = "Secret Plant: Get ghosted"
EventNames[341] = "Secret Plant: See the red light"
EventNames[342] = "Secret Plant: Something after being ghosted???"
EventNames[343] = "Secret Plant: Run away from the red light alarm"
EventNames[344] = "Secret Plant: Reach conveyor end as ghost"
EventNames[345] = "Secret Plant: Trigger the alarm"
EventNames[346] = "Secret Plant: *MISSABLE* Break alarm while Pac-man is looking at it."
EventNames[347] = "<untracked> Secret Plant: shot out of ghost form"
EventNames[348] = "Secret Plant: Free Pac-Man from the claw"
EventNames[349] = "Secret Plant: *MISSABLE!!* Enter from right BEFORE breaking light."
EventNames[350] = "Warehouse: Try to go back at the conveyor?"
EventNames[351] = "<untracked> <???> secret plant"
EventNames[352] = "Warehouse: See over conveyor edge"
EventNames[353] = "Locked Door: Look at left portrait"
EventNames[354] = "Locked Door: Look at right portrait"
EventNames[355] = "Biochemical Lab: Be scared of specimen"
EventNames[356] = "Biochemical Lab: See the laser tripwire"
EventNames[357] = "Biochemical Lab: *SNES ONLY* Set off tripwire"
EventNames[358] = "Biochemical Lab: Spin the chair"
EventNames[359] = "Biochemical Lab: See the chair"
EventNames[360] = "Biochemical Lab: Go to sit in chair"
EventNames[361] = "Biochemical Lab: Pac-Man asks to be spun"
EventNames[362] = "Biochemical Lab: Spin Pac-Man very fast in chair"
EventNames[363] = "Biochemical Lab: Spin chair after Pac asks (emotion 8)"
EventNames[364] = "<untracked> Biochemical Lab: Pac asks again to be spun"
EventNames[365] = "Biochemical Lab: Pac-Man falls out of very fast spin"
EventNames[366] = "Under Building: Chimney explodes in face"
EventNames[367] = "Biochemical Lab: Hit the beaker"
EventNames[368] = "Locked Door: *MISSABLE* Try to enter code w/o power pellet"
EventNames[369] = "Locked Door: *MISSABLE!!* Go to locked doors WITHOUT all 3 keys."
EventNames[370] = "Locked Door: Have the keycards"
EventNames[371] = "Locked Door: Enter a code"
EventNames[372] = "Locked Door: Start putting in keycards (#1)"
EventNames[373] = "Locked Door: Start putting in keycards (#2)"
EventNames[374] = "Sewers: Investigate outlet #3"
EventNames[375] = "<untracked> <???>"
EventNames[376] = "Sewers: Trip on can"
EventNames[377] = "Sewers: Shoot the can"
EventNames[378] = "Sewers: kick can in sewers, by making pacman LOOK at it."
EventNames[379] = "Secret Plant: Take conveyor past first machine"
EventNames[380] = "<untracked> Warehouse: Shoot box at entrance"
EventNames[381] = "Pulley Area/Sewers/others: Look left over edge of screen"
EventNames[382] = "Secret Plant: *SNES ONLY* Look left to run away from ghost machine."
EventNames[383] = "Secret Plant: See the ghost machine?"
EventNames[384] = "Top of Mtn: Look inside tree"
EventNames[385] = "<untracked> Construct Area: Investigate spinning cart wheel"
EventNames[386] = "Construct Area: Spin the cart wheel"
EventNames[387] = "<untracked> Top of Mtn: See balloon"
EventNames[388] = "Ropeway Station: Get hit by Dan Ger's rock"
EventNames[389] = "Ropeway Station: *SNES ONLY* Pac-man Looks at rock after it falls."
EventNames[390] = "Top of Mtn: Balloon got away by shooting pacman"
EventNames[391] = "Top of Mtn: Pop balloon"
EventNames[392] = "<untracked> Ropeway Station: Enter through big hole"
EventNames[393] = "<untracked> Ropeway Station: Look at big hole"
EventNames[394] = "Ropeway Station: Investigate the big hole"
EventNames[395] = "Arrival Point: See the drop"
EventNames[396] = "Arrival Point: Jump on rope, get rope burn"
EventNames[397] = "Arrival Point: Jump on rope, get shot off"
EventNames[398] = "<untracked> <???>"
EventNames[399] = "Arrival Point: *SNES ONLY* Shoot the minecart after climbing down rope"
EventNames[400] = "Entrance of Cave: Look down into chasm"
EventNames[401] = "<untracked> Entrance of Cave: first platform?"
EventNames[402] = "Entrance of Cave: Pacman stomps on and collapses platform"
EventNames[403] = "<untracked> Entrance of Cave: make it to other side?"
EventNames[404] = "Cliff: Trip over rock at takeoff"
EventNames[405] = "Cliff: Kick the rock"
EventNames[406] = "<untracked> <???>"
EventNames[407] = "Cliff: React to shooting rock."
EventNames[408] = "<untracked> Entrance of Cave: first platform?"
EventNames[409] = "Hillock: Shake the glider"
EventNames[410] = "Cliff: Investigate the guide"
EventNames[411] = "Ropeway Station: LOOK at the revealed hidden path"
EventNames[412] = "Ropeway Station: Shoot secret path"
EventNames[413] = "Hidden Runway: Slingshot the glider"
EventNames[414] = "Secret Underpass: Enter from minecart ride"
EventNames[415] = "<untracked> Ropeway Station: <???>"
EventNames[416] = "Stock Farm: Investigate the chicken"
EventNames[417] = "Stock Farm: Free the chicken"
EventNames[418] = "Stock Farm: Same as 419."
EventNames[419] = "Stock Farm: Shoot the chicken as it runs"
EventNames[420] = "Stock Farm: Chase chicken and bonk the tree"
EventNames[421] = "Stock Farm: See the beehive (?)"
EventNames[422] = "Stock Farm: See the bees (?)"
EventNames[423] = "<untracked> See bees?"
EventNames[424] = "Stock Farm: Get attacked by bees"
EventNames[425] = "Stock Farm: Shoot Pac-man so he lands on pointy rake."
EventNames[426] = "Stock Farm/Village Way: See the Crow"
EventNames[427] = "Stock Farm: Crow knocks over bottle"
EventNames[428] = "Stock Farm: Shoot the bottle, can't reach"
EventNames[429] = "Stock Farm: Break the bottle"
EventNames[430] = "Stock Farm: See the bottle"
EventNames[431] = "Stock Farm: Fill second milk bottle"
EventNames[432] = "Stock Farm: Sneak by the farmer"
EventNames[433] = "Stock Farm: Get caught by farmer"
EventNames[434] = "Stock Farm: Listen to the farmer's tale"
EventNames[435] = "Stock Farm: Knock rake to ground"
EventNames[436] = "Stock Farm: Step on rake"
EventNames[437] = "Stock Farm: Drop hay on farmer"
EventNames[438] = "Stock Farm: Sneak past haybaled farmer"
EventNames[439] = "Stock Farm: Clear hay from farmer"
EventNames[440] = "Stock Farm: See the cow?"
EventNames[441] = "Stock Farm: Fear the cow"
EventNames[442] = "Stock Farm: Swatted by cow tail"
EventNames[443] = "Stock Farm: Step on rake going other way, get hit back of head."
EventNames[444] = "Park: See caterpillar on ground"
EventNames[445] = "Pac-Man's House/Many places: React to birds"
EventNames[446] = "Pac-Man's House: Look behind the bush"
EventNames[447] = "Park: Fry the caterpillar by shooting it"
EventNames[448] = "Secret Plant: Look back when faced with ghost-making machine"
EventNames[449] = "Entrance of Cave: Drop platform out from under Pac-Man"
EventNames[450] = "Ropeway Station: Shoot the rock as it falls towards pac-man"
EventNames[451] = "Old Arcade: See ID Card"
EventNames[452] = "Top of Mtn: Pick up flower"
EventNames[453] = "<untracked> <???>"
EventNames[454] = "<untracked> <???>"
EventNames[455] = "<untracked> <???>"
EventNames[456] = "Village Way: Hit the door"
EventNames[457] = "Village Way: Bump into the door"
EventNames[458] = "Village Way: Get pancaked between door and wall"
EventNames[459] = "Village Way: Run into door"
EventNames[460] = "Village Way: Look back at opened door"
EventNames[461] = "Village Way: Fix the sign"
EventNames[462] = "Village Way: Knock on door, no response"
EventNames[463] = "<untracked> Village Way: Drop hay on rakeless farmer?"
EventNames[464] = "Village Way: Investigate the apple"
EventNames[465] = "Village Way: Shout at bird."
EventNames[466] = "Village Way: See apple on ground"
EventNames[467] = "Village Way: Investigate and poke spider"
EventNames[468] = "Village Way: Make spider climb back up web by shooting web."
EventNames[469] = "Village Way: Spider to the face"
EventNames[470] = "Village Way: Shoot the mailbox"
EventNames[471] = "Village Way: See open mailbox"
EventNames[472] = "Village Way: Mailbox door falls off"
EventNames[473] = "Village Way: Cherry desire"
EventNames[474] = "Village Way: See cherry on ground"
EventNames[475] = "Village Way: Play the slots"
EventNames[476] = "Village Way: Triple Cross Slots"
EventNames[477] = "Village Way: Triple Cherry Slots"
EventNames[478] = "Village Way: Sneak past dog"
EventNames[479] = "Village Way: Scared by dog"
EventNames[480] = "Village Way: Dog takes cherry to head"
EventNames[481] = "Locked Door: Look at opened door?"
EventNames[482] = "<untracked> <???>locked doorway"
EventNames[483] = "<untracked> <???>"
EventNames[484] = "Locked Door: Get rid of pellets while putting in correct code."
EventNames[485] = "Locked Door: Enter the unlocked doorway"
EventNames[486] = "Locked Door: Enter the correct code"
EventNames[487] = "Locked Door: Enter an incorrect code"
EventNames[488] = "Locked Door: Ghost attack after bad code"
EventNames[489] = "<untracked> <???>"
EventNames[490] = "Locked Door: *SNES ONLY* Pick up all three cards after wrong code entry"
EventNames[491] = "Locked Door: Be asked for code"
EventNames[492] = "Locked Door: *SNES ONLY* Shoot door after ghost attack."
EventNames[493] = "Village Way: After putting back on mailbox door."
EventNames[494] = "<untracked> <???>"
EventNames[495] = "Biochemical Lab: *SNES ONLY* shoot computer in bio chemical lab to deactivate laser"
EventNames[496] = "Sewers: Drop thieves' bundle"
EventNames[497] = "Sewers: Reveal the secret door"
EventNames[498] = "Sewers: *SNES ONLY* exit secret entrance in sewer"
EventNames[499] = "Sewers: same as 500."
EventNames[500] = "Sewers: spin pacman in revolving underground door"
EventNames[501] = "<untracked> <???> Unusued?"
EventNames[502] = "<untracked> <???> Unusued?"
EventNames[503] = "<untracked> <???> Unusued?"
EventNames[504] = "<untracked> <???> Unusued?"
EventNames[505] = "<untracked> <???> Unusued?"
EventNames[506] = "<untracked> <???> Unusued?"
EventNames[507] = "<untracked> <???> Unusued?"
EventNames[508] = "<untracked> <???> Unusued?"
EventNames[509] = "<untracked> <???> Unusued?"
EventNames[510] = "<untracked> <???> Unusued?"
EventNames[511] = "<untracked> <???> Unusued?"

--Create a matrix
--Rows are the location ID
--Collumns are events that can happen there.
--Later function will parse 0, nil, completed or not, required or not from the list.


local MasterList = {}
 for i=1,44 do
      MasterList[i] = {}     -- create a new row
      for j=1,50 do
        MasterList[i][j] = 0
      end
    end


--This is the list of every event that can occur on each screen.  This is subject to human error.
--Message me on Twitch at Solomon1973 if you find any errors.

local TutorialList = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 20, 21, 22, 23, 24, 25, 26, 34, 35, 36, 40, 41, 42, 43, 48, 50, 62, 64, 65, 66}
local PacmansHouseList = {68, 74, 75, 76, 77, 78, 80, 191, 192, 445, 446}
local VillageWayList = {50, 68, 213, 218, 426, 427, 456, 457, 458, 459, 460,461, 462, 464, 465,466,467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 493}
local ParkList = {60, 189, 190, 199, 200, 201, 202, 203, 204, 205, 206, 217, 218, 219, 267, 444, 445, 447}
local OldArcadeList = {47, 51, 67, 86, 87, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 179, 180, 198, 209, 219, 451}
local StockFarmList = {058, 059, 069, 213, 416, 417, 418, 419, 420, 421, 422, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 463}
local RopewayStationList = {50, 52, 53, 68, 80, 256, 257, 258, 271, 272, 273, 274, 312, 313, 314, 388, 389, 392, 394, 411, 412, 450}
local ForestList = {284, 285, 286, 287, 300, 304, 305, 306, 308, 309, 310, 311}
local EntranceToCaveList = {59, 159, 260, 261, 400, 401, 402, 403, 408, 410, 449}
local Minecart1List = {}
local ArrivalPointList = {053, 263, 264, 395, 396, 397, 399}
local ConstructionAreaList = {47, 86, 87, 275, 276, 277, 278, 279, 280, 281, 282, 283, 303, 317, 385, 386, 451}
local CliffList = {52, 213, 258, 259, 265, 270, 404, 405, 407, 410}
local Hanglider1List = {}
local HillockList = {213, 267, 268, 302, 318, 409}
local TopoftheMountainList = {270, 288, 289, 290, 291, 292, 293, 295, 296, 297, 384, 387, 390, 391, 452}
local StationStreetList = {97, 98, 99, 100, 101, 102, 103, 121, 122, 123, 124, 125, 126, 127, 179, 180, 210}
local FountainWayList = {88, 89, 90, 91, 92, 93, 104, 105, 106, 107, 108, 110, 111, 112, 113, 114, 115, 116, 118, 119, 120, 211, 212, 299, 445}
local MainStreetList = {70, 71, 72, 73, 96, 138, 151, 152, 153, 154, 181, 198, 332}
local IndustrialAreaList = {130, 131, 132, 133, 134, 155, 156, 157, 158, 163}
local SewerList = {320, 321, 322, 323, 324, 325, 326, 327, 328, 331, 332, 333, 334, 335, 374, 376, 377, 378, 496, 497, 498, 499, 500}
local WarehouseList = {329, 350, 352}
local SecretPlantList = {301, 330,  336, 337, 338, 339, 340, 341, 342, 343, 344, 345, 346, 348, 349, 350, 379, 382, 383, 448}
local BiochemicalLabList = {355, 356, 357, 358, 359, 360, 361, 362, 363, 365, 367, 495}
local LockedDoorList = {368, 369, 370, 371, 372, 373, 353, 354, 481, 484, 485, 486, 487, 488, 490, 491, 492}
local RooftopList = {047, 048, 050, 086, 087, 160, 198, 381, 451}
local PulleyAreaList = {052, 060, 135, 136, 137, 144, 145, 149, 159, 207, 208, 381}
local UnderBuildingList = {060, 135, 140, 183, 366, 381}
local InsidePacmansHouseList = {057, 049, 185, 195, 196, 197}
local LucysHouseList = {184, 185, 186, 187, 188}
local OldGameCenterList = {082, 094, 095, 178}
local GameCenterList = {082, 094, 095, 178}
local DepartmentStoreList = {54, 82, 139, 141, 142, 143, 146, 148, 150, 177, 220, 221, 332}
local GumMonsterList = {}
local SecretPathList = {260, 261, 410}
local Minecart2List = {}
local SecretUnderpassList = {414}
local SecretRunwayList = {270, 410, 413}
local Hanglider2List = {}

--Insert Tutorial events into matrix 				local tutvar = 1
	-- We will need to subtract 1 from row list later! since we can't have a slot 0 on an array and the tutorial is 0.
	for j=1,#TutorialList do
		MasterList[tutvar][j] = TutorialList[j]
	end
--Insert Pacman's House events into matrix   			local pmhvar = 4
	for j=1,#PacmansHouseList do
		MasterList[pmhvar][j] = PacmansHouseList[j]
	end
--Insert village way events into matrix    			 local vwvar = 5
	for j=1,#VillageWayList do
		MasterList[vwvar][j] = VillageWayList[j]
	end
--Insert park events into matrix				local pkvar = 6
	for j=1,#ParkList do
		MasterList[pkvar][j] = ParkList[j]
	end
--Insert Old Arcade events into matrix  			local oavar = 7
	for j=1,#OldArcadeList do
		MasterList[oavar][j] = OldArcadeList[j]
	end
--Insert Stock Farm events into matrix				local sfvar = 8
	for j=1,#StockFarmList do
		MasterList[sfvar][j] = StockFarmList[j]
	end

--Insert ropeway events into ropeway station			local rwsvar = 9
	for j=1,#RopewayStationList  do
		MasterList[rwsvar][j] = RopewayStationList[j]
	end
--Insert forest events into matrix				local frvar = 10
	for j=1,#ForestList  do
		MasterList[frvar][j] = ForestList[j]
	end
--Insert entrance to cave events into matrix			local etcvar = 11
	for j=1,#EntranceToCaveList  do
		MasterList[etcvar][j] = EntranceToCaveList[j]
	end
--Insert Minecart 1 events into matrix (note, there are none)	local mc1var = 12
	for j=1,#Minecart1List  do
		MasterList[mc1var][j] = Minecart1List[j]
	end
--Insert arrival point events into matrix			local apvar = 13
	for j=1,#ArrivalPointList  do
		MasterList[apvar][j] = ArrivalPointList[j]
	end

--Insert constructionArea events into matrix			local cavar = 14
	for j=1,#ConstructionAreaList  do
		MasterList[cavar][j] = ConstructionAreaList[j]
	end
--Insert cliff events into matrix				local cliffvar = 15
	for j=1,#CliffList  do
		MasterList[cliffvar][j] = CliffList[j]
	end
--Insert Hanglider into matrix which there are none		local hgl1var = 16
	for j=1,#Hanglider1List  do
		MasterList[hgl1var][j] = Hanglider1List[j]
	end
--Insert Hillock events into matrix				local hillvar = 17
	for j=1,#HillockList  do
		MasterList[hillvar][j] = HillockList[j]
	end
--Insert Top of the mountain events into matrix			local mtnvar = 18
	for j=1,#TopoftheMountainList  do
		MasterList[mtnvar][j] = TopoftheMountainList[j]
	end
--Insert station street events into matrix			local ssvar = 19
	for j=1,#StationStreetList  do
		MasterList[ssvar][j] = StationStreetList[j]
	end
--Insert fountain way events into matrix			local ftnvar = 20
	for j=1,#FountainWayList  do
		MasterList[ftnvar][j] = FountainWayList[j]
	end
--Insert main street events into matrix				local mstvar = 21
	for j=1,#MainStreetList  do
		MasterList[mstvar][j] = MainStreetList[j]
	end
--Insert Industrial Area events into matrix			local IAvar = 22
	for j=1,#IndustrialAreaList  do
		MasterList[IAvar][j] = IndustrialAreaList[j]
	end
--Insert sewer events into matrix				local swrvar = 23
	for j=1,#SewerList  do
		MasterList[swrvar][j] = SewerList[j]
	end
--Insert Warehouse events into matrix				local whsvar = 24
	for j=1,#WarehouseList  do
		MasterList[whsvar][j] = WarehouseList[j]
	end
--Insert Secret Plant events into matrix			local spntvar = 25
	for j=1,#SecretPlantList  do
		MasterList[spntvar][j] = SecretPlantList[j]
	end
--Insert Biochemical lab events into matrix			local biovar = 26
	for j=1,#BiochemicalLabList do
		MasterList[biovar][j] = BiochemicalLabList[j]
	end
--Insert locked door events into matrix				local ldrvar = 27
	for j=1,#LockedDoorList do
		MasterList[ldrvar][j] = LockedDoorList[j]
	end
--Insert Rooftop events into matrix				local rftpvar = 28
	for j=1,#RooftopList do
		MasterList[rftpvar][j] = RooftopList[j]
	end
--Insert Pully Area events into matrix				local pullyvar = 29
	for j=1,#PulleyAreaList do
		MasterList[pullyvar][j] = PulleyAreaList[j]
	end

--Insert Under Building events into matrix			local undbvar = 30
	for j=1,#UnderBuildingList do
		MasterList[undbvar][j] = UnderBuildingList[j]
	end

--Insert Inside Pacman's house events into matrix		local ipmhvar = 32
	for j=1,#InsidePacmansHouseList do
		MasterList[ipmhvar][j] = InsidePacmansHouseList[j]
	end
--Insert Lucy's House events into matrix			local lhvar = 33
	for j=1,#LucysHouseList do
		MasterList[lhvar][j] = LucysHouseList[j]
	end
--Insert Old Game Center events into matrix			local ogcvar = 34
	for j=1,#OldGameCenterList do
		MasterList[ogcvar][j] = OldGameCenterList[j]
	end

--Insert Game Center events into matrix				local gcntrvar = 36
	for j=1,#GameCenterList do
		MasterList[gcntrvar][j] = GameCenterList[j]
	end
--Insert Department store events into matrix			local dpmtsvar = 37
	for j=1,#DepartmentStoreList do
		MasterList[dpmtsvar][j] = DepartmentStoreList[j]
	end
--Insert Gum Monster events into matrix, of which there are none	local gmnstr = 38
	for j=1,#GumMonsterList do
		MasterList[gmnstr][j] = GumMonsterList[j]
	end
--Insert Secret Path events into matrix				local sctpthvar = 39
	for j=1,#SecretPathList do
		MasterList[sctpthvar][j] = SecretPathList[j]
	end
--Insert Minecart 2 events into matrix, of which there are none	local mcrt2var = 40
	for j=1,#Minecart2List do
		MasterList[mcrt2var][j] = Minecart2List[j]
	end
--Insert Secret Underpass events into matrix, 			local supassvar = 41
	for j=1,#SecretUnderpassList do
		MasterList[supassvar][j] = SecretUnderpassList[j]
	end
--Insert Secret Runway events into matrix,			local sctrnwyvar = 42
	for j=1,#SecretRunwayList do
		MasterList[sctrnwyvar][j] = SecretRunwayList[j]
	end
--Insert Hanglider 2 events into matrix, of which there are none	local hgdr2var = 43
	for j=1,#Hanglider2List do
		MasterList[hgdr2var][j] = Hanglider2List[j]
	end



local LastComplete = nil
local LastCompleteMatters = false
local ScriptFrameTime = 0
local ToastTimeout = 1000
local ToastFadeLength = 50
local MaxToasts = 5


--For inserting into strongs
function string.insert(str1, str2, pos)
    return str1:sub(1,pos)..str2..str1:sub(pos+1)
end

event.oninputpoll(
	function()
		--Get controller inputs
		local cInput = joypad.getimmediate()
		
		--Check each button and if it is pressed
		for k, v in pairs(cInput) do

			--Check if "L/X" is pressed, current emotion is at least 1 and the emotion is not locked
			--We change the emotion value -1
			--We also change the Pressed1 value to true to stop it from cycling every input poll
			if k == button1 and currentEmotion >= 1 and v and not lockedEmotion then
				if not Pressed1 then
					local newValue = currentEmotion - 1
					mmwl(p_emotion, newValue)
					Pressed1 = true
				end
			end

			--Once "L/X" is not pressed, we change Pressed1 value back to false
			if k == button1 and not v then
				Pressed1 = false
			end

			--Check if "R/Y" is pressed, current emotion is at most 14 and the emotion is not locked
			--We change the emotion value +1
			--We also change the Pressed2 value to true to stop it from cycling every input poll
			if k == button2 and v and currentEmotion < 15 and not lockedEmotion then
				if not Pressed2 then
					local newValue = currentEmotion + 1
					mmwl(p_emotion, newValue)
					Pressed2 = true
				end
			end
			
			--Once "R/Y" is not pressed, we change Pressed2 value back to false
			if k == button2 and not v then
				Pressed2 = false
			end

			--If "A/Z" is pressed we lock the emotion
			--We also change the Pressed3 value to true to stop it from changing on every input poll
			if k == button3 and v then
				if not Pressed3 then
					if not lockedEmotion then
						lockedEmotion = true
						lockedEmotionValue = currentEmotion
					else
						lockedEmotion = false
					end
					Pressed3 = true
				end
			end

			--Once "L/X" is not pressed, we change Pressed1 value back to false
			if k == button3 and not v then
				Pressed3 = false
			end
		end
	end
)

local function GetEventName(id)
    if (EventNames[id] == nil) then
        -- we should have a string for every possible id, but just in case...
        return "<unnamed>"
    else
        return EventNames[id]
    end
end

local function EventNumberReturn(str)
	local q
	local str2
	q = (string.find(str,":"))-1
	str2 = string.sub(str,1,q)
	--print (str)
	--print (str2)
	return tonumber(str2)
end

local function checkEvents(int)
	local temp = {}
	local temp2 = {}
	local temp1
	local string1
	local eventcolor

	--initialize temp
	count = #temp
	for k=0, count do temp[k]=nil end

	--Start the function
	for i=1,#MasterList[int] do
		--if it's not 0 or nil...
		if (MasterList[int][i] ~= 0 and MasterList[int][i] ~= nil) then
			temp1 = tonumber(MasterList[int][i])
			--if it's not completed...
			 if (CompletionTrack[temp1] == false) then	
				-- AND if it's required...
				 if (RequiredTrack[temp1] == true) then	
					table.insert(temp, MasterList[int][i])
					--but if Untrackedmod is active we add it anyway.
				elseif (RequiredTrack[temp1] == false and visible == true) then
					table.insert(temp, MasterList[int][i])
				end
			end
		end
	end

	--initialize temp
	count = #temp

	for k=1, count do
	temp2[k]= temp[k] .. ": " .. EventNames[temp[k]]
	end

	--initialize temp
	count = #temp2

	if (count < 1) then
		text(7, 28, "Area Complete!!", ColorTracked)
	else
		
		for l=1, count do 
			if (visible == true) then
				if (RequiredTrack[EventNumberReturn(temp2[l])] == false) then
					eventcolor = ColorUntracked
				else
					eventcolor = ColorTracked
				end
			else
				eventcolor = ColorTracked
			end
		text(7, (l*7+21), temp2[l], eventcolor)
	
	--string2 = table.concat(temp2,"\n")
	--text(7, 28, string2, ColorTracked)
		end
	end
end  -- \n

-- Mostly so we can keep track of how many things we've got names for.
local function DebugGetNamingProgress()
    local total_trackables = 322
    local unnamed_trackables = 0

    for k,name in pairs(EventNames) do
        if (name == "<???>") then
            unnamed_trackables = unnamed_trackables + 1
        end
    end

    local named_trackables = total_trackables - unnamed_trackables

 --   console.log(string.format("DEBUG: Have names for %d/%d (%.2f%%).", named_trackables, total_trackables, 100*named_trackables/total_trackables))
end
DebugGetNamingProgress()

local Toasts = {}

local function AddToast(str, color)
    -- insert into the front
    table.insert(Toasts, 1, { ["str"] = str, ["color"] = color, ["time"] = ScriptFrameTime })

    -- forcibly remove the oldest toast if we have too many at once
    if (#Toasts > MaxToasts) then
        table.remove(Toasts)
    end
end



-- set color alpha from 0.0 to 1.0
local function SetColorAlpha(color, alpha)
    if (alpha > 1.0) then
        alpha = 1.0
    end
    if (alpha < 0.0) then
        alpha = 0.0
    end
     
    return (AND(0x00FFFFFF, color) + SHIFTL(alpha*255, 24))
end

-- Show toast messages
local function ShowToasts()
    local lineno = 0

    for k,toast in pairs(Toasts) do
        local been_up_for = ScriptFrameTime - toast.time
        local color = toast.color
        if (been_up_for > (ToastTimeout - ToastFadeLength)) then
            color = SetColorAlpha(color, (ToastTimeout - been_up_for) / ToastFadeLength)
        end

        text(56, lineno*8, toast.str, color)
        lineno = lineno + 1
    end

    -- get rid of toasts that have been on-screen for too long
    for k,toast in pairs(Toasts) do
        if (ScriptFrameTime - toast.time > ToastTimeout) then
            table.remove(Toasts, k)
        end
    end
end

-- Get and draw the completion percentage
-- Also keep track of which events have been newly-completed, and add toasts for them.
local function GetCompletionPercentage()
    local completion_total = 0
    local completion_done = 0
    local uncompletion_total = 0
    local uncompletion_done = 0	

    for i = 0, 0xf do
        local state_value = memory.read_u32_le(ObjectStatesAddr + (i*4), ObjectStatesDomain)
        local mask_value = memory.read_u32_le(ObjectMasksAddr + (i*4), ObjectMasksDomain)

        for b = 0, 31 do
            local counts_toward_completion = (AND(mask_value, SHIFTL(1, b)) ~= 0)
            local has_been_completed = (AND(state_value, SHIFTL(1, b)) ~= 0)
            local id = SHIFTL(i, 5) + b

            if (counts_toward_completion) then
                completion_total = completion_total + 1

                if (has_been_completed) then
                    completion_done = completion_done + 1
                end
	    else
		uncompletion_total = uncompletion_total + 1	
		if (has_been_completed) then
                    uncompletion_done = uncompletion_done + 1
                end
            end

            if (has_been_completed) then
                if (CompletionTrack[id] == false) then
                    CompletionTrack[id] = true
                    LastComplete = id
                    LastCompleteMatters = counts_toward_completion
                end
            end
        end
    end

    text(0, line1, string.format("%d/%d (%d%%)", completion_done, completion_total, completion_done * 100 / completion_total), ColorProgress)
    text(0, line2, string.format("%d/%d (%d%%)", uncompletion_done, uncompletion_total, uncompletion_done * 100 / uncompletion_total), ColorUntracked)
--    text(0, line3, string.format("%d%%/200%%", math.floor(completion_done * 100 / --completion_total)+math.floor(uncompletion_done * 100 / uncompletion_total)), ColorTracked)

    if (LastComplete) then
        local name = GetEventName(LastComplete)
        if (LastCompleteMatters) then
            AddToast(string.format("%d: %s", LastComplete, name), ColorTracked)
        else
            AddToast(string.format("%d: %s", LastComplete, name), ColorUntracked)
        end
        LastComplete = nil
    end
end

local function ShowProgress()
    for i = 0, 0xf do
        local state_value = memory.read_u32_le(ObjectStatesAddr + (i*4), ObjectStatesDomain)
        local mask_value = memory.read_u32_le(ObjectMasksAddr + (i*4), ObjectMasksDomain)

        for b = 0, 31 do
            local counts_toward_completion = (AND(mask_value, SHIFTL(1, b)) ~= 0)
            local has_been_completed = (AND(state_value, SHIFTL(1, b)) ~= 0)
            local id = SHIFTL(i, 5) + b
            local color = ColorUntracked

            if (counts_toward_completion) then
                 color = ColorTracked
            end

            local y = 40+7*math.floor(id / 50)
            local x = 5+5*(id % 50)

            if (has_been_completed) then
                text(x, y, 'X', color)
            else
                text(x, y, '-', color)
            end
        end
    end

    -- top-side tens and ones-digit numbers
    for i = 0, 49 do
        local x = 5+5*i

        if (i % 10 == 0) then
            text(x, 26, string.format("%d", math.floor(i/10)), ColorProgress)
        end
        text(x, 33, string.format("%d", i%10), ColorProgress)
    end

    -- left-side hundreds-digit numbers
    for i = 0, 5 do
        local y = 40+7*i*2
        text(0, y, string.format("%d", i), ColorProgress)
    end
end



while true do
    if (not client.isturbo()) then
        ScriptFrameTime = ScriptFrameTime + 1

        GetCompletionPercentage()

        ShowToasts()

        local inputs = joypad.get()

	if (inputs[button4] and inputs[button5] and inputs[button1]==false) then
	 	 if currentLocation == 0 then
	  		 checkEvents(44)
	    	else
	 		 checkEvents(currentLocation)
		end
	end

        if (inputs[button5] and inputs[button5] and inputs[button1]) then
            ShowProgress()
        end


	if (inputs[button1] and inputs[button2] and inputs[button5] and inputs[button4] and pressed==false ) then
           	 if visible == false then
			visible = true
			line1 = 0
			line2 = 7
			line3 = 14
			line4 = 14
			pressed = true
	  	  else
			visible = false
			line1 = 0
			line2 = 1000
			line3 = 1000
			line4 = 7
			pressed = true
	   	 end
        end
	if pressed == true and inputs[button1] == false and inputs[button2] == false and inputs[button4] == false and inputs[button5] == false then
		pressed = false
	end
    else
        text(0, 0, "(>>)", ColorProgress)
    end

     --Constantly check the current location
	currentLocation = mmrl(location )
	--gui.pixelText(0, line5, "Location: " ..currentLocation, ColorTracked)

    --Constantly check the current emotion value
	currentEmotion = mmrl(p_emotion)

	--If the emotion lock is not active, set our text color value to "yellow"
	--If the emotion lock is active, set our text color to "red" and change the address value to our lock value
	if not lockedEmotion then
		textColor = "yellow"
	else
		mmwl(p_emotion, lockedEmotionValue)
		textColor = "red"
	end


    gui.pixelText(0, line4, "Emotion: " ..currentEmotion, textColor)


    emu.frameadvance()
end

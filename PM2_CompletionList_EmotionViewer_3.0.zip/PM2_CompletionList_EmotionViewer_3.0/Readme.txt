Script for discovering what makes the completion percentage in
Pac-Man 2: The New Adventures (GEN/SNES) tick.
Modified by SolomonSTB1973 to make emotion handler work with SNES ROM.
Version 3.0!
Fully supports GEN, Super Famicom and European SNES versions.
Adds new type of area-specific tracker (old tracker still in game)
Adds "untracked" mode, which shows a percentage for untracked events (toggled on/off)
Not 100% tested, but should work.  Also, event names still need revising

originally written by Slabbityslab and Insomnimatics, with help finding events by kickasspancakes, AludraKijurorin, Mr Wayne and BaconOmelette, shoutouts to Danilo Roxette

Warning: This script was designed to work with BizHawk-2.6.2-win-x64.  Using it on any version other than 2.6.2 will cause it to throw up errors.

This script should work with any version of the Pac-Man 2 / Hello Pacman ROM.  

Controls:

SNES/Famicon:
"Press B+X to view Area Events Tracker."
"Press L/R to change emotions."
"Press A to lock emotions."
"Press B+X+L to view Total Events Tracker."
"Press B+X+L+R to toggle Untracked mode."

Genesis:
"Press A+B to view Area Events Tracker."
"Press X/Y to change emotions."
"Press Z to lock emotions."
"Press A+B+X to view Total Events Tracker."
"Press A+B+X+Y to toggle Untracked mode."

Disclaimer: Much of the work that went into this script was done by people other than me.  I made the script work on all versions of the game, added a screen-by-screen list, and found a few of the final missing events.
originally written by Slabbityslab and Insomnimatics, with help finding events by kickasspancakes, AludraKijurorin, Mr Wayne and BaconOmelette, shoutouts to Danilo Roxette
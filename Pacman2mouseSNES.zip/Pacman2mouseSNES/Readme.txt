--Written by BaconOmelette for Genesis
--modified by SolomonSTB1973
--Works for both Pac-man 2 and Hello Pac-man.

Disclaimer: I did not write this script, I just modified it to work with the SNES Hello Pacman / Pac-man 2 rom.
Original author: BaconOmelette


Copy/pasted from BaconOmelette's setup guide for their Genesis version:

Pac-Man 2 Genesis Keyboard and Mouse Control by BaconOmelette

---

Setup:
1)Remove double click full screen in bizhawk: Config>Display>Window>Uncheck "Allow Double-Click Fullscreen" (see figure1).
2)Remove right click menu in bizhawk: Config>Customize>Uncheck "Enable Context Menu" (see figure2).
3)Load the appropriate lua script file based on your Genplus-gx Settings: GEN>Settings (see figure3).
	If Pad Screen to 320 is set to True, use the "pacman2mouse_padtrue.lua" script.
	If Pad Screen to 320 is set to False, use the "pacman2mouse_padfalse.lua" script.

---

Recommended Use:
Bind controller buttons A and B to mouse click inputs to your liking
Bind controller button C to overlap with controller DPAD bindings (This creates an instant look direction binding).
	To set multiple bindings on C button, uncheck "Auto Tab" in the bizhawk controller setting window.

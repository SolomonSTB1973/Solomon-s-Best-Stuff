--Written by BaconOmelette for Genesis
--modified by SolomonSTB1973
--Works for both Pac-man 2 and Hello Pac-man.

while true do
	mouseinput = input.getmouse()
	memory.write_u16_le((0x001062),(mouseinput["X"]))
	memory.write_u16_le((0x001066),(mouseinput["Y"]))
	emu.frameadvance()
end
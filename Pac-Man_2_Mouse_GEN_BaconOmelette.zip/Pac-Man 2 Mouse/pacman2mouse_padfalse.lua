while true do
	mouseinput = input.getmouse()
	memory.write_u16_be((0xFFDE10),(mouseinput["X"]+121))
	memory.write_u16_be((0xFFDE14),(mouseinput["Y"]+121))
	emu.frameadvance()
end